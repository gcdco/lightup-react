import React from 'react'

function LightUp() {
    return (
        <div>
            
        </div>
    )
}

export default LightUp
